/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookmanagment;

/**
 *
 * @author PC
 */
abstract class BookandUser{
    private String a;
    private String s;
    private int numara;

    public   abstract void isExist( String a);
    public abstract String printt(String a,String s ,int numara);  



}



